@extends('adminlte::page')

@section('content')

<div class="box">
  <div class="box-header with-border">
    <h3 class="box-title">Generat Students Matric</h3>
  </div>
  <div class="box-body">
  <div class="row">
        <div class="col-sm-4">
          
        </div>
      </div>
  </div>

</div>
@endsection

