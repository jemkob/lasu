@extends('adminlte::page')

@section('content')
{{-- <script src="../js/angular.min.js"></script> --}}

<div class="box">
  <div class="box-header with-border">
    <h3 class="box-title">Student Manager</h3>
    
  </div>
  <div style="padding-left:10px; padding-right:10px;">
  <div style="float:right;"><a href ="studentmanager/create" class="btn btn-primary"><i class="fa fa-lg fa-plus"></i> Add New</a></div>
    <div style="float:left;">
      </div>
  </div>
    <div class="box-body">

        resulthere
          

    </div>

</div>
@endsection

