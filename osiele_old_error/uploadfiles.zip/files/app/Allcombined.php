<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Allcombined extends Model
{
    //
    protected $table = 'allcombineds';
    protected $primaryKey = 'AllCombinedID';
}
